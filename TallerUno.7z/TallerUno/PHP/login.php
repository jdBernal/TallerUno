<html>
<head>
<title>Registro de Usuarios</title>
</head>
<body>
<h1>
<strong>Login </strong></h1>
  <form action="procesaDosTallerUno.php" method="post" name="datos">
   
    Usuario:<input name="Usuario" type="text" /><br>
    Password:<input type="Password" name="Password"  /><br>
    
      <input type="submit" value="Enviar" />

  </form>

    <form action="registroUsuarios.php" method="post" name="datos">
   
    
      <input type="submit" value="Nuevo?" />

  </form>
</body>
</html>