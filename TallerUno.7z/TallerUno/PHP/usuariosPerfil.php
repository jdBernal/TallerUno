

<html>
<body>
Login Successful 
<?php

$hostname = 'localhost'; 
$user = 'root'; 
$pass = '';

session_start();

$con = mysql_connect($hostname,$user,$pass);
   if (!$con){die("ERROR DE CONEXION CON MYSQL: " . mysql_error());}

   $database = mysql_select_db("taller1",$con);
   if (!$database){die("ERROR CONEXION CON BD: ".mysql_error());}
 
?>

<strong> Sube Contenido </strong></h1>

 <form action="contenidosProcesa.php" method="post" name="datos">
   

    Contenido:<input name="Contenido" type="text" /><br>

     <input type="submit" value="Post" /><br>
</form>

<?php



   	$result = mysql_query("SELECT * FROM post WHERE usuario='".$_SESSION['Usuario']."'",$con) or die(mysql_error());

while ($row = mysql_fetch_array($result)) {
	echo $row ['contenido']."<br />";
  }
?>
 <br>
 <br>

 <form action="main2.php" method="post" name="datos">
   

     <input type="submit" value="HOME" /><br>
     </form>

     <br>

<p>
		LogOut
	</p>


<form action="Logout.php"  method="post" value="out" >


   
    <input type="submit" value="EXIT" name="salir_log"/>
</form>
</body>
</html>





