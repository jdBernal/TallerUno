<?php
    include "archivesTallerUno.php";
   session_start();
  


$query = mysql_query("SELECT username FROM Users WHERE username='$username' ");
 if(mysql_num_rows($query)!=0)
   {
    echo"name already exists";
   }
 else
    {
       $sql="INSERT INTO post VALUES  ('".$_POST['Contenido']."','".$_SESSION['Usuario']."')";
            echo $sql;
             $result = mysql_query($sql);
                if (! $result){
                               echo "La consulta SQL contiene errores:".mysql_error();
                               exit();
                }else {header("location:main2.php");
  }
    }
