

<html>
<body>
Login Successful <br>

<?php
include("archivesTallerUno.php");

session_start();
 echo $_SESSION['Usuario'] ."<br />"; 
?>

<strong> Sube Contenido </strong>

 <form action="procesaMainContenido.php" method="post"  value="contenido">
   

    Contenido:<input name="Contenido" type="text" /><br>

     <input type="submit" value="Post" name="datos"/><br>

</form>

<p>
		Mi Perfil
	</p>


<form action="usuariosPerfil.php"  method="post" value="perfil">

 <input type="submit" value="IR" name="datos"/><br>

</form>



<?php

$query = "SELECT usuario FROM usuarios WHERE 1";
echo "<p class = 'debug'>";
$resultado = mysql_query($query) OR die("<p class='Error de bases de Query'>Query erronea1:".mysql_error()."</p></p>");


while ($row = mysql_fetch_array($resultado)) {
	echo $row ['usuario']."<br />";
}


?>
<br>
<form action="perfiles.php" method="post"  value="Usuario">
   

    Usuario:<input name="Usuario" type="text" /><br>

     <input type="submit" value="BUSCAR" name="datos"/><br>

</form>

<br>

<p>
		LogOut
	</p>


<form action="Logout.php"  method="post" value="out" >


   
    <input type="submit" value="EXIT" name="salir_log"/>
</form>


</body>
</html>