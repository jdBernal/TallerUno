<?php 


include("archivesTallerUno.php");

$Username= $_POST['Usuario'];
$Password= $_POST['Password'];


$Username = stripslashes($Username);
$Password = stripslashes($Password);
$Username = mysql_real_escape_string($Username);
$Password = mysql_real_escape_string($Password);
$sql="SELECT * FROM usuarios WHERE usuario='$Username' and password='$Password'";
$result=mysql_query($sql);


$count=mysql_num_rows($result);


if($count==1){

session_start();

$_SESSION['Usuario']=$_POST['Usuario'];
$_SESSION['Password']='Password';
header("location:main2.php");


}
else {
echo "Wrong Username or Password";
}
?>







