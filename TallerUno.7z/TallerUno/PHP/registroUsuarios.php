<html>
<head>
<title>Registro de Usuarios</title>
</head>
<body>
<h1>
<strong>Nuevos Usuarios </strong></h1>
  <form action="procesaTallerUno.php" method="post" name="datos">
   
    Usuario:<input name="Usuario" type="text" /><br>
    Password:<input type="Password" name="Password"  /><br>
    
      <input type="submit" value="Enviar" />

  </form>
</body>
</html>