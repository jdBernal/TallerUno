<?php
$hostname = 'localhost'; 
$user = 'root'; 
$pass = '';

$con = mysql_connect($hostname,$user,$pass);
   if (!$con){die("ERROR DE CONEXION CON MYSQL: " . mysql_error());}

   $database = mysql_select_db("taller1",$con);
   if (!$database){die("ERROR CONEXION CON BD: ".mysql_error());}





?>